// JavaScript Document
function onecl()
{
	"use strict";
	var len=paths.length;
	for (var i=0;i<len;i++)
		{
			var nme="li"+(i+1);
			document.getElementById(nme).href=paths[i];
			document.getElementById(nme).innerHTML=pthtonme(paths[i]);
			
		}
}
function pthtonme(inp)
{
	"use strict";
	var len= inp.length; var pos;
	for (var i=len-1;i>-1;i--)
		{
			if (inp.charAt(i)==='/')
				{
					pos=i;
					break;
				}
		}
	var out=inp.substring(pos+1,len);
	return out;
}
function upload(postUrl, fieldName, filePath)
{
	"use strict";
  var formData = new FormData();
  formData.append(fieldName, new File(filePath));

  var req = new XMLHttpRequest();
  req.open("POST", postUrl);
  req.onload = function(event) { alert(event.target.responseText); };
  req.send(formData);
}
onecl();